import{r as e}from"./rolldown-runtime-BCiCTKAo.js";import{t}from"./sha3-CJCkyGor.js";import{t as n}from"./preload-helper-BDhOGCXB.js";var r=class{#e=[];#t=[];take(e){let t=this.#e.shift();return t===void 0?new Promise((t,n)=>{let r={resolve:n=>{e?.removeEventListener(`abort`,i),t(n)},reject:t=>{e?.removeEventListener(`abort`,i),n(t)}},i=()=>{let t=this.#t.indexOf(r);t>=0&&this.#t.splice(t,1),n(e?.reason??new DOMException(`aborted`,`AbortError`))};if(e?.aborted)return i();e?.addEventListener(`abort`,i,{once:!0}),this.#t.push(r)}):Promise.resolve(t)}push(e){let t=this.#t.shift();t?t.resolve(e):this.#e.push(e)}pushFront(e){let t=this.#t.shift();t?t.resolve(e):this.#e.unshift(e)}remove(e){let t=this.#e.indexOf(e);return t<0?!1:(this.#e.splice(t,1),!0)}rejectAll(e){let t=this.#e.splice(0);for(let t of this.#t.splice(0))t.reject(e);return t}},i=class{#e=[];#t=[];#n;#r;constructor(e){this.#r=e}dropped=0;take(e){let t=this.#e.shift();return t===void 0?this.#n?Promise.reject(this.#n.err):new Promise((t,n)=>{let r={resolve:n=>{e?.removeEventListener(`abort`,i),t(n)},reject:t=>{e?.removeEventListener(`abort`,i),n(t)}},i=()=>{let t=this.#t.indexOf(r);t>=0&&this.#t.splice(t,1),n(e?.reason??new DOMException(`aborted`,`AbortError`))};if(e?.aborted)return i();e?.addEventListener(`abort`,i,{once:!0}),this.#t.push(r)}):Promise.resolve(t)}push(e){if(this.#n)return;let t=this.#t.shift();if(t)return t.resolve(e);for(this.#e.push(e);this.#e.length>this.#r;)this.#e.shift(),this.dropped++}close(e){if(!this.#n){this.#n={err:e};for(let t of this.#t.splice(0))t.reject(e)}}get size(){return this.#e.length}};function a(e){let t=``;for(let n of e)t+=n.toString(16).padStart(2,`0`);return t}var o=c(`workerHash()`),s=c(`workerResolvers()`);function c(e){return`0x`+a(t(new TextEncoder().encode(e))).slice(0,8)}function l(e){let t=e.startsWith(`0x`)?e.slice(2):e,n=new Uint8Array(t.length/2);for(let e=0;e<n.length;e++)n[e]=parseInt(t.slice(e*2,e*2+2),16);return n}async function u(e,t){let n=await d(e,t,o),r=await d(e,t,s);return{workerHash:`0x`+te(n),resolvers:ne(r)}}async function d(e,t,n){let r=await e.request({method:`eth_call`,params:[{to:t,data:n},`latest`]});if(typeof r!=`string`)throw Error(`eth_call did not return data`);return l(r)}var f=67108864;async function p(e,t){let n=()=>Error(`body exceeds the ${t}-byte bundle cap`);if(!e.body){let r=new Uint8Array(await e.arrayBuffer());if(r.byteLength>t)throw n();return r}let r=e.body.getReader(),i=[],a=0;for(;;){let{value:e,done:o}=await r.read();if(o)break;if(a+=e.byteLength,a>t)throw await r.cancel().catch(()=>{}),n();i.push(e)}let o=new Uint8Array(a),s=0;for(let e of i)o.set(e,s),s+=e.byteLength;return o}async function ee(e,n=f,r=[]){let i=[];for(let o of e.resolvers){let s;try{if(/^(https?|blob):/.test(o)){let e=await fetch(o);if(!e.ok)throw Error(`HTTP ${e.status}`);s=await p(e,n)}else{let e=r.find(e=>e.matches(o));if(!e){i.push(`${o}: unrecognized resolver kind (ignored)`);continue}s=await e.fetch(o,n)}}catch(e){i.push(`${o}: ${e.message}`);continue}let c=`0x`+a(t(s));if(c!==e.workerHash)i.push(`${o}: hash mismatch (got ${c}, want ${e.workerHash})`);else return s}throw Error(`no resolver yielded bytes matching workerHash: ${i.join(`; `)}`)}function te(e){if(e.length<32)throw Error(`short bytes32 return`);return a(e.slice(0,32))}function m(e,t){if(t<0||t+32>e.length)throw Error(`ABI decode: word out of bounds`);let n=0;for(let r=t;r<t+32;r++)if(n=n*256+e[r],n>2**53-1)throw Error(`ABI decode: word too large`);return n}function ne(e){let t=m(e,0),n=m(e,t);if(t+32+n*32>e.length)throw Error(`ABI decode: array length out of bounds`);let r=[],i=new TextDecoder;for(let a=0;a<n;a++){let n=t+32+m(e,t+32+a*32),o=m(e,n);if(n+32+o>e.length)throw Error(`ABI decode: string out of bounds`);r.push(i.decode(e.slice(n+32,n+32+o)))}return r}function h(e,t=`value`){return g(e,t,new Set)}function g(e,t,n){switch(typeof e){case`undefined`:case`boolean`:case`number`:case`string`:return e;case`object`:break;default:throw v(t,typeof e)}if(e===null)return null;if(e instanceof Uint8Array){if(_(e.buffer))throw v(t,`a Uint8Array over a detached buffer`);return new Uint8Array(e)}if(e instanceof ArrayBuffer){if(_(e))throw v(t,`a detached ArrayBuffer`);return e.slice(0)}if(n.has(e))throw v(t,`a value that contains itself`);n.add(e);try{if(Array.isArray(e)){let r=Array(e.length);for(let i=0;i<e.length;i++)r[i]=g(e[i],`${t}[${i}]`,n);return r}let r=Object.getPrototypeOf(e);if(r!==Object.prototype&&r!==null)throw v(t,re(e));let i={};for(let r of Object.keys(e))Object.defineProperty(i,r,{value:g(e[r],`${t}.${r}`,n),writable:!0,enumerable:!0,configurable:!0});return i}finally{n.delete(e)}}function _(e){return e.detached===!0}function re(e){let t=e.constructor?.name;return typeof t==`string`&&t?`a ${t}`:`an object with a non-plain prototype`}function v(e,t){return TypeError(`${e} is not a plain value (\xA79.4): got ${t}`)}function ie(e,t=`value`){return y(h(e,t))}function y(e){switch(typeof e){case`undefined`:return[`u`];case`number`:return Number.isNaN(e)?[`n`,`NaN`]:e===1/0?[`n`,`Infinity`]:e===-1/0?[`n`,`-Infinity`]:Object.is(e,-0)?[`n`,`-0`]:e;case`boolean`:case`string`:return e}if(e===null)return null;if(e instanceof Uint8Array)return[`b`,a(e)];if(e instanceof ArrayBuffer)return[`ab`,a(new Uint8Array(e))];if(Array.isArray(e))return[`a`,...e.map(y)];let t=[`o`];for(let n of Object.keys(e))t.push(n,y(e[n]));return t}function b(e){if(!Array.isArray(e))return e;switch(e[0]){case`u`:return;case`n`:return Number(e[1]);case`b`:return x(e[1]);case`ab`:return x(e[1]).buffer;case`a`:return e.slice(1).map(b);case`o`:{let t={};for(let n=1;n<e.length;n+=2)Object.defineProperty(t,e[n],{value:b(e[n+1]),writable:!0,enumerable:!0,configurable:!0});return t}}}function x(e){let t=new Uint8Array(e.length>>1);for(let n=0;n<t.length;n++)t[n]=parseInt(e.slice(n*2,n*2+2),16);return t}var ae=new Set([`method`,`headers`,`body`,`redirect`,`signal`]);function S(e){if(!e)return;let t;for(let n of Object.keys(e))ae.has(n)||(t??={},Object.defineProperty(t,n,{value:h(e[n],`init.${n}`),writable:!0,enumerable:!0,configurable:!0}));return t}var C=class extends Error{code;constructor(e){super(e.message),this.name=e.name,this.code=e.code}};function w(e){if(e instanceof Error){let t=e.code;return{name:e.name,message:e.message,...typeof t==`string`?{code:t}:{}}}return{name:`Error`,message:String(e)}}function oe(e){let t=()=>Error(`address: malformed (expected <ip>:<port>:<certhash> or [ipv6]:<port>:<certhash>): ${e}`),n,r;if(e.startsWith(`[`)){let i=e.indexOf(`]`);if(i<0||e[i+1]!==`:`)throw t();n=e.slice(1,i),r=e.slice(i+2)}else{let i=e.indexOf(`:`);if(i<0)throw t();n=e.slice(0,i),r=e.slice(i+1)}let i=r.indexOf(`:`);if(i<0)throw t();let a=r.slice(0,i),o=r.slice(i+1);if(!/^\d+$/.test(a))throw t();let s=Number(a);if(s<1||s>65535)throw Error(`address: port out of range`);if(!n||!o)throw t();return{ip:n,port:s,certhash:o}}var T=`u`,se=18,ce=32;function E(e){if(!e.startsWith(T))throw Error(`certhash: expected multibase prefix '${T}', got '${e[0]??``}'`);let t=ue(e.slice(1));if(t.length!==34)throw Error(`certhash: expected 34 bytes, got ${t.length}`);if(t[0]!==se||t[1]!==ce)throw Error(`certhash: not a sha2-256 multihash (prefix ${t[0].toString(16)} ${t[1].toString(16)})`);return t.slice(2)}function le(e){return Array.from(e,e=>e.toString(16).padStart(2,`0`).toUpperCase()).join(`:`)}function ue(e){let t=(4-e.length%4)%4,n=e.replace(/-/g,`+`).replace(/_/g,`/`)+`=`.repeat(t),r=atob(n),i=new Uint8Array(r.length);for(let e=0;e<r.length;e++)i[e]=r.charCodeAt(e);return i}function D(e){let t=Error(e.message??`kps: stream ${e.code??`reset`}`);return t.code=e.code,t}function O(e){if(e!=null)return typeof e==`object`&&(`code`in e||`message`in e)?e:{message:String(e?.message??e)}}var de=16384,fe=16383,k=(1n<<62n)-1n,A=class extends Error{},j={cancelled:1,closed:2,reset:3,timeout:4,"network-error":5,"protocol-error":6,unsupported:7,"too-large":8,"queue-full":9,"permission-denied":10,"internal-error":11},pe=Object.fromEntries(Object.entries(j).map(([e,t])=>[t,e]));function M(e){return e?j[e]??0:0}function N(e){return e===0?void 0:pe[e]??`internal-error`}function me(e){let t=new Uint8Array(1+e.length);return t[0]=0,t.set(e,1),t}function he(){return new Uint8Array([1])}function P(e,t){let n=new Uint8Array(5);return n[0]=e,new DataView(n.buffer).setUint32(1,t>>>0,!1),n}function ge(e){let t=new Uint8Array(9);return t[0]=4,new DataView(t.buffer).setBigUint64(1,e,!1),t}function _e(e){if(e.length===0)throw new A(`empty data-channel message`);if(e.length>16384)throw new A(`frame exceeds ${de} bytes (${e.length})`);let t=e[0],n=e.subarray(1),r=()=>new DataView(n.buffer,n.byteOffset,n.byteLength);switch(t){case 0:if(n.length===0)throw new A(`empty DATA frame`);return{type:`data`,payload:n};case 1:if(n.length!==0)throw new A(`FIN with payload`);return{type:`fin`};case 2:if(n.length!==4)throw new A(`RESET payload must be 4 bytes`);return{type:`reset`,code:r().getUint32(0,!1)};case 3:if(n.length!==4)throw new A(`STOP_SENDING payload must be 4 bytes`);return{type:`stop-sending`,code:r().getUint32(0,!1)};case 4:{if(n.length!==8)throw new A(`MAX_STREAM_DATA payload must be 8 bytes`);let e=r().getBigUint64(0,!1);if(e>k)throw new A(`MAX_STREAM_DATA above MAX_OFFSET`);return{type:`max-stream-data`,value:e}}default:throw new A(`unknown frame type 0x${t.toString(16)}`)}}function F(e){let t=new Uint8Array(5);return t[0]=0,new DataView(t.buffer).setUint32(1,M(e),!1),t}function I(e,t=1){let n=new Uint8Array(26),r=new DataView(n.buffer);return n[0]=1,n[1]=t,r.setBigUint64(2,e.initialMaxStreamData,!1),r.setBigUint64(10,e.initialMaxData,!1),r.setBigUint64(18,e.initialMaxStreams,!1),n}function ve(e){let t=new Uint8Array(9);return t[0]=2,new DataView(t.buffer).setBigUint64(1,e,!1),t}function ye(e){let t=new Uint8Array(9);return t[0]=3,new DataView(t.buffer).setBigUint64(1,e,!1),t}function be(e){if(e.length===0)throw new A(`empty control message`);let t=e[0],n=new DataView(e.buffer,e.byteOffset,e.byteLength);switch(t){case 0:if(e.length!==5)throw new A(`CONNECTION_CLOSE must be 5 bytes`);return{t:`close`,code:n.getUint32(1,!1)};case 1:{if(e.length!==26)throw new A(`HELLO must be 26 bytes`);let t={initialMaxStreamData:n.getBigUint64(2,!1),initialMaxData:n.getBigUint64(10,!1),initialMaxStreams:n.getBigUint64(18,!1)};for(let e of Object.values(t))if(e>k)throw new A(`HELLO credit above MAX_OFFSET`);return{t:`hello`,version:e[1],limits:t}}case 2:{if(e.length!==9)throw new A(`MAX_DATA must be 9 bytes`);let t=n.getBigUint64(1,!1);if(t>k)throw new A(`MAX_DATA above MAX_OFFSET`);return{t:`max-data`,value:t}}case 3:{if(e.length!==9)throw new A(`MAX_STREAMS must be 9 bytes`);let t=n.getBigUint64(1,!1);if(t>k)throw new A(`MAX_STREAMS above MAX_OFFSET`);return{t:`max-streams`,value:t}}default:throw new A(`unknown control message type 0x${t.toString(16)}`)}}var xe=1n<<20n,Se=8n<<20n;function Ce(e){return{initialMaxStreamData:e?.initialMaxStreamData??xe,initialMaxData:e?.initialMaxData??Se,initialMaxStreams:e?.initialMaxStreams??100n}}function L(e){return e>k?k:e}var we=class{#e=[];wake(){let e=this.#e;this.#e=[];for(let t of e)t()}wait(e){return new Promise((t,n)=>{if(e){let r=()=>n(Error(`kps: aborted`));e.addEventListener(`abort`,r,{once:!0}),this.#e.push(()=>{e.removeEventListener(`abort`,r),t()})}else this.#e.push(t)})}},Te=class{local;#e=0n;#t=0n;#n=0n;#r=0n;#i=0n;#a=0n;#o=0n;#s;#c=0n;#l=0n;#u=0n;#d=0n;#f=0n;#p;#m=new we;#h=null;#g;constructor(e,t){this.local=e,this.#s=e.initialMaxData,this.#p=e.initialMaxStreams,this.#g=t}onPeerHello(e){this.#e=e.initialMaxStreamData,this.#t=e.initialMaxData,this.#n=e.initialMaxStreams,this.#m.wake()}onPeerMaxData(e){e>this.#t&&(this.#t=e,this.#m.wake())}onPeerMaxStreams(e){e>this.#n&&(this.#n=e,this.#m.wake())}fail(e){this.#h||(this.#h=e,this.#m.wake())}wake(){this.#m.wake()}get failed(){return this.#h}get peerInitialMaxStreamData(){return this.#e}newStream(e){return new Ee(this,this.local.initialMaxStreamData,e)}async reserveData(e,t,n){for(;;){if(this.#h)throw this.#h;let r=e.sendFailed;if(r)throw r;if(n?.aborted)throw Error(`kps: aborted`);let i=e.peerMaxStreamData-e.sendSent-e.sendReserved,a=this.#t-this.#r-this.#i,o=i<a?i:a;if(o>t&&(o=t),o>=1n)return e.sendReserved+=o,this.#i+=o,o;await this.#m.wait(n)}}commitData(e,t){e.sendReserved-=t,e.sendSent+=t,this.#i-=t,this.#r+=t}releaseData(e,t){e.sendReserved-=t,this.#i-=t,this.#m.wake()}async reserveStreamSlot(e){for(;;){if(this.#h)throw this.#h;if(e?.aborted)throw Error(`kps: aborted`);if(this.#a+this.#o<this.#n){this.#o+=1n;return}await this.#m.wait(e)}}commitStreamSlot(){this.#o-=1n,this.#a+=1n}releaseStreamSlot(){this.#o-=1n,this.#m.wake()}connDataReceived(e){if(this.#c+e>this.#s)throw new A(`peer exceeded MAX_DATA`);this.#c+=e}connDataConsumed(e){this.#l+=e;let t=this.local.initialMaxData;this.#l-this.#u>=t/2n&&(this.#u=this.#l,this.#s=L(this.#l+t),this.#g.sendMaxData(this.#s))}peerStreamOpened(){if(this.#d>=this.#p)throw new A(`peer exceeded MAX_STREAMS`);this.#d+=1n}peerStreamRetired(){this.#f+=1n,this.#p=L(this.local.initialMaxStreams+this.#f),this.#g.sendMaxStreams(this.#p)}},Ee=class{sendSent=0n;sendReserved=0n;#e=0n;#t=null;#n;#r=0n;#i=0n;#a=0n;#o=!1;#s;#c;constructor(e,t,n){this.#s=e,this.#n=t,this.#c=n}get peerMaxStreamData(){let e=this.#s.peerInitialMaxStreamData;return this.#e>e?this.#e:e}async reserve(e,t){return Number(await this.#s.reserveData(this,BigInt(e),t))}commit(e){this.#s.commitData(this,BigInt(e))}release(e){this.#s.releaseData(this,BigInt(e))}failSend(e){this.#t||(this.#t=e,this.#s.wake())}get sendFailed(){return this.#t}onPeerMaxStreamData(e){e>this.#e&&(this.#e=e,this.#s.wake())}onDataReceived(e){let t=BigInt(e);if(this.#r+t>this.#n)throw new A(`peer exceeded MAX_STREAM_DATA`);this.#s.connDataReceived(t),this.#r+=t}onConsumed(e){let t=BigInt(e);this.#i+=t;let n=this.#s.local.initialMaxStreamData;!this.#o&&this.#i-this.#a>=n/2n&&(this.#a=this.#i,this.#n=L(this.#i+n),this.#c(this.#n)),this.#s.connDataConsumed(t)}markCancelled(){this.#o=!0}},R=1<<20,z=class{#e=[];wake(){let e=this.#e;this.#e=[];for(let t of e)t()}wait(){return new Promise(e=>this.#e.push(e))}},De=class{readable;writable;closed;opened;#e;#t;#n;#r=[];#i=!1;#a=null;#o=null;#s=null;#c=!1;#l=null;#u=!1;#d=!1;#f=new z;#p=new z;#m;#h=!1;#g;#_;#v=!1;constructor(e,t,n){this.#e=e,this.#n=n,this.#t=t.newStream(e=>{this.#e.isOpen()&&this.#e.send(ge(e))}),this.closed=new Promise(e=>{this.#m=e}),this.opened=new Promise((e,t)=>{this.#g=e,this.#_=t}),this.opened.catch(()=>{}),e.setBufferedAmountLowThreshold(R),e.onBufferedAmountLow(()=>this.#p.wake()),e.onOpen(()=>this.#D(null)),e.isOpen()&&this.#D(null),e.onMessage(e=>this.#y(e)),e.onClose(()=>this.#b()),e.onError(e=>{this.#E({ok:!1,reason:{code:`network-error`,message:e}}),this.#D(Error(`kps: stream failed: ${e}`)),this.#f.wake(),this.#p.wake()}),this.readable=new ReadableStream({pull:async e=>{for(;;){if(this.#c){e.error(D(this.#l??{code:`cancelled`}));return}let t=this.#r.shift();if(t){e.enqueue(t),this.#t.onConsumed(t.length),this.#T();return}if(this.#a){e.error(D(this.#a));return}if(this.#i){e.close();return}if(this.#u){e.error(D({code:`network-error`,message:`kps: stream closed`}));return}await this.#f.wait()}},cancel:e=>{this.cancelRead(O(e)??{code:`cancelled`})}},{highWaterMark:0}),this.writable=new WritableStream({write:e=>this.#x(e),close:()=>this.closeWrite(),abort:e=>this.resetWrite(O(e)??{code:`reset`})})}#y(e){let t;try{t=_e(e)}catch(e){this.#n.fatal({code:`protocol-error`,message:e.message});return}switch(t.type){case`data`:if(this.#i||this.#a){this.#n.fatal({code:`protocol-error`,message:`DATA after terminal frame`});return}try{this.#t.onDataReceived(t.payload.length)}catch(e){this.#n.fatal({code:`protocol-error`,message:e.message});return}if(this.#c){this.#t.onConsumed(t.payload.length);return}this.#r.push(t.payload.slice()),this.#f.wake();return;case`fin`:if(this.#i||this.#a){this.#n.fatal({code:`protocol-error`,message:`second terminal frame`});return}this.#i=!0,this.#f.wake(),this.#T();return;case`reset`:if(this.#i||this.#a){this.#n.fatal({code:`protocol-error`,message:`second terminal frame`});return}this.#a={code:N(t.code)??`reset`},this.#w(),this.#f.wake(),this.#T();return;case`stop-sending`:if(this.#o)return;this.#o={code:N(t.code)??`cancelled`},this.#t.failSend(D(this.#o)),this.#s||(this.#s=`reset`,this.#e.isOpen()&&this.#e.send(P(2,t.code)),this.#T());return;case`max-stream-data`:this.#t.onPeerMaxStreamData(t.value);return}}#b(){this.#u=!0,!(this.#s!==null&&(this.#i||this.#a!==null))&&!this.#n.isTeardown()&&this.#n.fatal({code:`protocol-error`,message:`data channel closed mid-stream`}),this.#t.failSend(D({code:`network-error`,message:`kps: stream closed`})),this.#D(Error(`kps: stream closed before opening`)),this.#E({ok:!this.#a,reason:this.#a??void 0}),this.#f.wake(),this.#p.wake(),this.#T()}async#x(e){let t=0;for(;t<e.length;){this.#S();let n=Math.min(e.length-t,fe),r=await this.#t.reserve(n),i=e.subarray(t,t+r);try{await this.#C(),this.#S(),this.#e.send(me(i))}catch(e){throw this.#t.release(r),e}this.#t.commit(r),t+=r}}#S(){if(this.#o)throw D(this.#o);if(this.#s)throw D({code:`closed`,message:`kps: write half closed`});if(this.#u||!this.#e.isOpen())throw Error(`kps: stream is closed`)}async#C(){for(;this.#e.isOpen()&&this.#e.bufferedAmount()>=R;)await this.#p.wait()}async closeWrite(){this.#s||(this.#s=`fin`,this.#t.failSend(D({code:`closed`,message:`kps: write half closed`})),this.#e.isOpen()&&this.#e.send(he()),this.#T())}async cancelRead(e){this.#c||(this.#c=!0,this.#l=e??{code:`cancelled`},this.#t.markCancelled(),this.#w(),!this.#i&&!this.#a&&this.#e.isOpen()&&this.#e.send(P(3,M(e?.code??`cancelled`))),this.#f.wake(),this.#T())}async resetWrite(e){this.#s||(this.#s=`reset`,this.#t.failSend(D(e??{code:`reset`})),this.#e.isOpen()&&this.#e.send(P(2,M(e?.code??`reset`))),this.#T())}async close(e){try{await this.closeWrite()}catch{}try{await this.cancelRead(e??{code:`closed`})}catch{}}destroy(e){this.#w(),this.#c=!0,this.#l=e??{code:`closed`,message:`kps: connection closed`},this.#t.failSend(D(e??{code:`closed`,message:`kps: connection closed`})),this.#D(Error(`kps: connection closed`)),this.#E(e?{ok:!1,reason:e}:{ok:!0}),this.#f.wake(),this.#p.wake()}#w(){if(this.#r.length===0)return;let e=0;for(let t of this.#r)e+=t.length;this.#r=[],this.#t.onConsumed(e)}#T(){this.#s!==null&&(this.#i||this.#a!==null)&&this.#r.length===0&&(this.#u?this.#d||(this.#d=!0,this.#n.retired()):this.#e.close())}#E(e){this.#h||(this.#h=!0,this.#m(e))}#D(e){this.#v||(this.#v=!0,e?this.#_(e):this.#g())}},B=1200,Oe=`_kps_control`,ke=`_kps_datagrams`,Ae=15e3,je=256;function Me(e,t,n){return t?t.aborted?Promise.reject(Error(n)):new Promise((r,i)=>{let a=()=>i(Error(n));t.addEventListener(`abort`,a,{once:!0}),e.then(e=>{t.removeEventListener(`abort`,a),r(e)},e=>{t.removeEventListener(`abort`,a),i(e)})}):e}var Ne=class{closed;established;flow;#e;#t=`connecting`;#n=!1;#r=!1;#i=null;#a=!1;#o;#s;#c;#l=0;#u=new Set;#d=[];#f=[];#p=[];#m=[];#h=[];#g;#_=!1;constructor(e){this.#e=e,this.closed=new Promise(e=>{this.#g=e}),this.established=new Promise((e,t)=>{this.#o=e,this.#s=t}),this.established.catch(()=>{}),this.flow=new Te(Ce(e.limits),{sendMaxData:e=>this.#x(ve(e)),sendMaxStreams:e=>this.#x(ye(e))}),e.control.onOpen(()=>this.#v()),e.control.onMessage(e=>this.#y(e)),e.control.onClose(()=>this.#S(`control`)),e.control.onError(()=>this.#S(`control`)),e.control.isOpen()&&this.#v(),e.datagram.onMessage(e=>this.#T(e)),e.datagram.onClose(()=>this.#S(`datagram`)),this.#c=setTimeout(()=>this.fatal({code:`timeout`,message:`kps: HELLO timeout`}),e.helloTimeoutMs??Ae),this.#c.unref?.()}get state(){return this.#t}#v(){this.#r||this.#_||(this.#r=!0,this.#x(I(this.flow.local)),this.#b())}#y(e){let t;try{t=be(e)}catch(e){this.fatal({code:`protocol-error`,message:e.message});return}switch(t.t){case`hello`:if(this.#i){this.fatal({code:`protocol-error`,message:`duplicate HELLO`});return}if(t.version!==1){this.#x(F(`unsupported`)),this.#E({ok:!1,reason:{code:`unsupported`,message:`kps: peer wire version ${t.version} (want 1)`}});return}this.#i=t.limits,this.flow.onPeerHello(t.limits),this.#b();return;case`close`:{let e=t.code===0?void 0:{code:N(t.code)??`internal-error`};this.#E({ok:t.code===0,reason:e});return}case`max-data`:if(!this.#i){this.fatal({code:`protocol-error`,message:`control message before HELLO`});return}this.flow.onPeerMaxData(t.value);return;case`max-streams`:if(!this.#i){this.fatal({code:`protocol-error`,message:`control message before HELLO`});return}this.flow.onPeerMaxStreams(t.value);return}}#b(){if(this.#a||this.#_||!this.#r||!this.#i)return;this.#a=!0,this.#t=`open`,clearTimeout(this.#c),this.#o();let e=this.#d;this.#d=[];for(let t of e)this.#w(t)}#x(e){try{this.#e.control.isOpen()&&this.#e.control.send(e)}catch{}}#S(e){this.#n||this.#_||this.fatal({code:`protocol-error`,message:`kps: reserved ${e} channel lost`})}handleIncomingChannel(e){try{this.flow.peerStreamOpened()}catch(e){this.fatal({code:`protocol-error`,message:e.message});return}let t=this.#C(e,!0);this.#a?this.#w(t):this.#d.push(t)}#C(e,t){let n=new De(e,this.flow,{fatal:e=>this.fatal(e),retired:()=>{this.#u.delete(n),t&&this.flow.peerStreamRetired()},isTeardown:()=>this.#n});return this.#u.add(n),n}#w(e){let t=this.#p.shift();t?t.resolve(e):this.#f.push(e)}async openStream(e={}){if(e.signal?.aborted)throw Error(`kps: openStream aborted`);if(this.#t!==`open`)throw Error(`kps: connection is ${this.#t}`);await this.flow.reserveStreamSlot(e.signal);let t;try{t=this.#e.openChannel(`kps-${++this.#l}`)}catch(e){throw this.flow.releaseStreamSlot(),e}this.flow.commitStreamSlot();let n=this.#C(t,!1);try{await Me(n.opened,e.signal,`kps: openStream aborted`)}catch(e){throw n.opened.then(()=>{n.resetWrite({code:`cancelled`}),n.cancelRead({code:`cancelled`})}).catch(()=>{}),e}return n}acceptStream(e={}){let t=this.#f.shift();if(t)return Promise.resolve(t);if(e.signal?.aborted)return Promise.reject(Error(`kps: acceptStream aborted`));if(this.#t===`closed`)return Promise.reject(Error(`kps: connection is closed`));let n=e.signal;return new Promise((e,t)=>{let r={resolve:t=>{n?.removeEventListener(`abort`,i),e(t)},reject:e=>{n?.removeEventListener(`abort`,i),t(e)}},i=()=>{let e=this.#p.indexOf(r);e>=0&&this.#p.splice(e,1),t(Error(`kps: acceptStream aborted`))};this.#p.push(r),n?.addEventListener(`abort`,i,{once:!0})})}#T(e){let t=this.#h.shift();t?t.resolve(e):(this.#m.push(e),this.#m.length>je&&this.#m.shift())}async sendDatagram(e,t){if(t?.signal?.aborted)throw Error(`kps: sendDatagram aborted`);if(e.length>1200){let e=Error(`kps: datagram exceeds limit (max ${B} bytes)`);throw Object.assign(e,{code:`too-large`,maxDatagramPayloadSize:B}),e}if(!this.#e.datagram.isOpen())throw Error(`kps: datagram channel not open`);this.#e.datagram.send(e)}receiveDatagram(e){let t=this.#m.shift();if(t)return Promise.resolve(t);if(this.#t===`closed`)return Promise.reject(Error(`kps: connection closed`));if(e?.signal?.aborted)return Promise.reject(Error(`kps: receiveDatagram aborted`));let n=e?.signal;return new Promise((e,t)=>{let r={resolve:t=>{n?.removeEventListener(`abort`,i),e(t)},reject:e=>{n?.removeEventListener(`abort`,i),t(e)}},i=()=>{let e=this.#h.indexOf(r);e>=0&&this.#h.splice(e,1),t(Error(`kps: receiveDatagram aborted`))};this.#h.push(r),n?.addEventListener(`abort`,i,{once:!0})})}close(e){this.#_||(this.#n=!0,this.#x(F(e?.code)),this.#E({ok:!0,reason:e}))}fatal(e){this.#_||(this.#n=!0,this.#x(F(e.code??`protocol-error`)),this.#E({ok:!1,reason:e}))}onTransportFailed(e=`peer connection failed`){this.#E({ok:!1,reason:{code:`network-error`,message:e}})}onTransportClosed(){this.#E({ok:this.#t!==`connecting`})}#E(e){if(this.#_)return;this.#_=!0,this.#n=!0,this.#t=`closed`,clearTimeout(this.#c);let t=e.reason?D(e.reason):Error(`kps: connection closed`);this.#a||this.#s(t),this.flow.fail(t);for(let t of[...this.#u,...this.#d])t.destroy(e.reason);this.#u.clear(),this.#d=[];for(let e of this.#p)e.reject(Error(`kps: connection closed`));this.#p=[];for(let e of this.#h)e.reject(Error(`kps: connection closed`));this.#h=[];try{this.#e.closeTransport()}catch{}this.#g(e)}};function Pe(){let e=new Uint8Array(8);return crypto.getRandomValues(e),Array.from(e,e=>e.toString(16).padStart(2,`0`)).join(``)}async function Fe(e,t){let n=await crypto.subtle.importKey(`raw`,V(e),{name:`HMAC`,hash:`SHA-256`},!1,[`sign`]),r=new TextEncoder().encode(`kps-ice-pwd-v1:`+t),i=new Uint8Array(await crypto.subtle.sign(`HMAC`,n,V(r))),a=``;for(let e of i)a+=String.fromCharCode(e);return btoa(a).replace(/=+$/,``)}function V(e){return e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength)}function Ie(e,t,n){return e.split(/\r\n|\n/).map(e=>e.startsWith(`a=ice-ufrag:`)?`a=ice-ufrag:${t}`:e.startsWith(`a=ice-pwd:`)?`a=ice-pwd:${n}`:e).join(`\r
`)}function Le(e,t,n){let r=le(E(e.certhash)),i=e.ip.includes(`:`),a=i?`IP6`:`IP4`;return[`v=0`,`o=- 0 0 IN ${a} ${i?`::`:`0.0.0.0`}`,`s=-`,`t=0 0`,`a=ice-lite`,`m=application ${e.port} UDP/DTLS/SCTP webrtc-datachannel`,`c=IN ${a} ${e.ip}`,`a=mid:0`,`a=ice-ufrag:${t}`,`a=ice-pwd:${n}`,`a=fingerprint:sha-256 ${r}`,`a=setup:passive`,`a=sctp-port:5000`,`a=max-message-size:1048576`,`a=candidate:1 1 UDP 1 ${e.ip} ${e.port} typ host`].join(`\r
`)+`\r
`}var Re=15e3;function ze(e){return e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength)}function H(e){let t=e.reason;return Error(t?.name===`TimeoutError`?`kps: dial timed out`:`kps: dial aborted`)}var U=class{#e;#t=null;#n=null;#r=null;#i=null;#a=null;constructor(e){this.#e=e,e.binaryType=`arraybuffer`,e.addEventListener(`message`,e=>{let t=e.data,n=typeof t==`string`?new TextEncoder().encode(t):new Uint8Array(t);this.#t?.(n)}),e.addEventListener(`open`,()=>this.#n?.()),e.addEventListener(`close`,()=>this.#r?.()),e.addEventListener(`error`,e=>{this.#i?.(e.error?.message??`data channel error`)}),e.addEventListener(`bufferedamountlow`,()=>this.#a?.())}isOpen(){return this.#e.readyState===`open`}send(e){this.#e.send(ze(e))}bufferedAmount(){return this.#e.bufferedAmount}setBufferedAmountLowThreshold(e){this.#e.bufferedAmountLowThreshold=e}onBufferedAmountLow(e){this.#a=e}onMessage(e){this.#t=e}onOpen(e){this.#n=e}onClose(e){this.#r=e}onError(e){this.#i=e}close(){try{this.#e.close()}catch{}}},Be=class e{remoteAddress;#e;#t;constructor(e,t,n){this.#e=e,this.remoteAddress=n;let r=e.createDataChannel(ke,{negotiated:!0,id:1,ordered:!1,maxRetransmits:0});this.#t=new Ne({control:new U(t),datagram:new U(r),openChannel:t=>new U(e.createDataChannel(t)),closeTransport:()=>{try{e.close()}catch{}}}),e.addEventListener(`connectionstatechange`,()=>{let t=e.connectionState;t===`failed`?this.#t.onTransportFailed():t===`closed`&&this.#t.onTransportClosed()}),e.addEventListener(`datachannel`,e=>{let t=e.channel;t.label!==`_kps_control`&&t.label!==`_kps_datagrams`&&this.#t.handleIncomingChannel(new U(t))})}get closed(){return this.#t.closed}static async dial(t,n={}){let r=n.signal??AbortSignal.timeout(Re);if(r.aborted)throw H(r);let i=oe(t),a=E(i.certhash),o=new RTCPeerConnection({}),s=o.createDataChannel(Oe,{negotiated:!0,id:0}),c=await o.createOffer(),l=Pe(),u=await Fe(a,l);await o.setLocalDescription({type:c.type,sdp:Ie(c.sdp??``,l,u)}),await o.setRemoteDescription({type:`answer`,sdp:Le(i,l,u)});let d=new e(o,s,{ip:i.ip,port:i.port});return await d.#n(r),d}#n(e){return new Promise((t,n)=>{let r=()=>{try{this.#e.close()}catch{}n(H(e))};e.addEventListener(`abort`,r,{once:!0}),this.#t.established.then(()=>{e.removeEventListener(`abort`,r),t()},t=>{e.removeEventListener(`abort`,r),n(t)})})}openStream(e={}){return this.#t.openStream(e)}acceptStream(e={}){return this.#t.acceptStream(e)}async close(e){this.#t.close(e)}sendDatagram(e,t){return this.#t.sendDatagram(e,t)}receiveDatagram(e){return this.#t.receiveDatagram(e)}};function W(e,t){return Be.dial(e,t)}async function G(e,t){let n=await W(e,t);try{let e=await n.openStream({signal:t?.signal});return e.closed.finally(()=>{n.close()}),e}catch(e){throw await n.close(),e}}var Ve=e({openStream:()=>G}),He=class{#e;#t=1;#n=new Map;#r=new Map;#i=new Map;#a=new Map;constructor(e){this.#e=e,e.onmessage=e=>this.#s(e.data),e.start?.()}on(e,t){this.#r.set(e,t)}onEvent(e,t){this.#i.set(e,t)}emit(e,t,n){this.#o({t:`evt`,topic:e,data:t},n)}call(e,t,n){let r=this.#t++;return new Promise((i,a)=>{let o;if(n?.signal){let e=n.signal;if(e.aborted){a(K());return}let t=()=>{this.#n.delete(r)&&(this.#o({t:`abort`,id:r}),a(K()))};e.addEventListener(`abort`,t),o=()=>e.removeEventListener(`abort`,t)}this.#n.set(r,{resolve:i,reject:a,cleanup:o}),this.#o({t:`req`,id:r,method:e,args:t},n?.transfer)})}#o(e,t){this.#e.postMessage(e,t??[])}async#s(e){switch(e.t){case`evt`:this.#i.get(e.topic)?.(e.data);return;case`abort`:this.#a.get(e.id)?.abort(K());return;case`res`:{let t=this.#n.get(e.id);if(!t)return;this.#n.delete(e.id),t.cleanup?.(),e.ok?t.resolve(e.value):t.reject(new C(e.error));return}case`req`:{let t=this.#r.get(e.method);if(!t){this.#o({t:`res`,id:e.id,ok:!1,error:{name:`Error`,message:`no handler: ${e.method}`}});return}let n=new AbortController;this.#a.set(e.id,n);try{let r=await t(e.args,{signal:n.signal});this.#o({t:`res`,id:e.id,ok:!0,value:r.value},r.transfer)}catch(t){this.#o({t:`res`,id:e.id,ok:!1,error:w(t)})}finally{this.#a.delete(e.id)}return}}}};function K(){return new DOMException(`The operation was aborted.`,`AbortError`)}function Ue(e){let t=new Map,n=new Map,r=1,i=t=>{let i=r++;return n.set(i,t),t.closed.then(t=>{n.delete(i),e.emit(`stream.closed`,{streamId:i,info:t})}),{value:{streamId:i,readable:t.readable,writable:t.writable},transfer:[t.readable,t.writable]}},a=e=>{let n=t.get(e);if(!n)throw Error(`unknown connId ${e}`);return n},o=e=>{let t=n.get(e);if(!t)throw Error(`unknown streamId ${e}`);return t};return e.on(`kps.dial`,async({addr:n},{signal:i})=>{let a=await W(n,{signal:i}),o=r++;return t.set(o,a),a.closed.then(n=>{t.delete(o),e.emit(`conn.closed`,{connId:o,info:n})}),{value:{connId:o,remoteAddress:a.remoteAddress}}}),e.on(`kps.openStream`,async({addr:e},{signal:t})=>{let n=await G(e,{signal:t});return i(n)}),e.on(`conn.openStream`,async({connId:e},{signal:t})=>i(await a(e).openStream({signal:t}))),e.on(`conn.acceptStream`,async({connId:e},{signal:t})=>i(await a(e).acceptStream({signal:t}))),e.on(`conn.close`,async({connId:e,reason:n})=>(await a(e).close(n),t.delete(e),{value:void 0})),e.on(`conn.sendDatagram`,async({connId:e,data:t},{signal:n})=>(await a(e).sendDatagram(t,{signal:n}),{value:void 0})),e.on(`conn.receiveDatagram`,async({connId:e},{signal:t})=>({value:await a(e).receiveDatagram({signal:t})})),e.on(`stream.closeWrite`,async({streamId:e})=>(await o(e).closeWrite(),{value:void 0})),e.on(`stream.cancelRead`,async({streamId:e,reason:t})=>(await o(e).cancelRead(t),{value:void 0})),e.on(`stream.resetWrite`,async({streamId:e,reason:t})=>(await o(e).resetWrite(t),{value:void 0})),e.on(`stream.close`,async({streamId:e,reason:t})=>(await o(e).close(t),n.delete(e),{value:void 0})),()=>{for(let e of n.values())e.close({code:`closed`}).catch(()=>{});for(let e of t.values())e.close({code:`closed`});n.clear(),t.clear()}}async function We(e,t){let n=S(t);if(e instanceof Request){let r=t?.body instanceof ReadableStream,i=t?new Request(e,{...r?{duplex:`half`}:{},...t}):e,a=[];i.headers.forEach((e,t)=>a.push([t,e]));let o={method:i.method,headers:a,redirect:i.redirect,hasSignal:!0};n&&(o.forwarded=n);let s=[];return i.body&&(o.body=i.body,s.push(i.body)),{url:i.url,requestInit:o,transfer:s,signal:i.signal}}let r=typeof e==`string`?e:e.href;if(!t)return{url:r};let i=t,a=[],o,s;if(i.body!=null){if(i.body instanceof ReadableStream)o=i.body,a.push(i.body);else if(typeof i.body==`string`)o=new TextEncoder().encode(i.body),a.push(o.buffer);else if(i.body instanceof Uint8Array||i.body instanceof ArrayBuffer)o=i.body instanceof Uint8Array?i.body:new Uint8Array(i.body);else{let e=new Response(i.body);o=new Uint8Array(await e.arrayBuffer()),s=e.headers.get(`content-type`)??void 0,a.push(o.buffer)}}let c={};i.method&&(c.method=i.method);let l=Ge(i.headers)??[];return s&&!l.some(([e])=>e.toLowerCase()===`content-type`)&&l.push([`content-type`,s]),l.length&&(c.headers=l),o!==void 0&&(c.body=o),i.redirect&&(c.redirect=i.redirect),i.signal&&(c.hasSignal=!0),n&&(c.forwarded=n),{url:r,requestInit:c,transfer:a,signal:i.signal??void 0}}function Ge(e){if(!e)return;let t=[];if(e instanceof Headers)e.forEach((e,n)=>t.push([n,e]));else if(Array.isArray(e))for(let[n,r]of e)t.push([n,r]);else for(let[n,r]of Object.entries(e))t.push([n,String(r)]);return t}var Ke=`anon-rpc-harness`,q=`kv`;function qe(){return typeof indexedDB>`u`?Promise.resolve(new Ye):Je.open()}function J(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}var Je=class e{#e;constructor(e){this.#e=e}static async open(){let t=indexedDB.open(Ke,1);return t.onupgradeneeded=()=>{t.result.createObjectStore(q)},new e(await J(t))}#t(e){return this.#e.transaction(q,e).objectStore(q)}async get(e,t){return await J(this.#t(`readonly`).get([e,t]))}async set(e,t,n){await J(this.#t(`readwrite`).put(n,[e,t]))}async delete(e,t){await J(this.#t(`readwrite`).delete([e,t]))}async has(e,t){return await J(this.#t(`readonly`).getKey([e,t]))!==void 0}async listKeys(e,t=``){let n=[];return await this.#n(`readonly`,e,t,e=>{n.push(e.key[1])}),n}async clear(e,t=``){await this.#n(`readwrite`,e,t,e=>{e.delete()})}#n(e,t,n,r){return new Promise((i,a)=>{let o=this.#t(e),s=IDBKeyRange.lowerBound([t,n]),c=e===`readwrite`?o.openCursor(s):o.openKeyCursor(s);c.onsuccess=()=>{let e=c.result;if(!e)return i();let[a,o]=e.key;if(a!==t||!o.startsWith(n))return i();r(e),e.continue()},c.onerror=()=>a(c.error)})}},Ye=class{#e=new Map;#t(e){let t=this.#e.get(e);return t||this.#e.set(e,t=new Map),t}async get(e,t){return this.#t(e).get(t)}async set(e,t,n){this.#t(e).set(t,n)}async delete(e,t){this.#t(e).delete(t)}async has(e,t){return this.#t(e).has(t)}async listKeys(e,t=``){return[...this.#t(e).keys()].filter(e=>e.startsWith(t))}async clear(e,t=``){let n=this.#t(e);if(!t)return n.clear();for(let e of[...n.keys()])e.startsWith(t)&&n.delete(e)}},Xe=new TextEncoder,Y=`\r
`;function Ze(e){if(!e.startsWith(`kps:`))return;let t=e.slice(4),n=t.indexOf(`/`);if(n<=0)throw Error(`malformed kps resolver: missing /path`);let r=t.slice(0,n),i=t.slice(n);if(r.split(`:`).length<3)throw Error(`malformed kps resolver: bad address`);return{addr:r,path:i}}function X(e,t,n=[]){let r=n.length?`Accept-Encoding: ${n.join(`, `)}${Y}`:``;return Xe.encode(`GET ${e} HTTP/1.1${Y}Host: ${t}${Y}${r}${Y}`)}var Z=[[`zstd`,[`zstd`]],[`br`,[`br`,`brotli`]],[`gzip`,[`gzip`]],[`deflate`,[`deflate`]]];function Q(){return globalThis.DecompressionStream}function $(e){let t=Q();if(t)for(let n of Z.find(([t])=>t===e)?.[1]??[])try{return new t(n),n}catch{}}function Qe(){return Z.map(([e])=>e).filter(e=>$(e)!==void 0)}async function $e(e,t,n){let r=Q(),i=$(e);if(!r||i===void 0)throw Error(`undecodable Content-Encoding: ${e}`);let a=new Blob([t]).stream().pipeThrough(new r(i)).getReader(),o=[],s=0;for(;;){let{value:e,done:t}=await a.read();if(t)break;if(s+=e.byteLength,s>n)throw await a.cancel().catch(()=>{}),Error(`decoded body exceeds the ${n}-byte bundle cap`);o.push(e)}let c=new Uint8Array(s),l=0;for(let e of o)c.set(e,l),l+=e.byteLength;return c}function et(e){let t=tt(e);if(t<0)throw Error(`no header terminator in response`);let n=new TextDecoder(`utf-8`,{fatal:!1}).decode(e.subarray(0,t)).split(Y),r=/^HTTP\/1\.1 (\d{3})(?: |$)/.exec(n[0]);if(!r)throw Error(`malformed status line: ${JSON.stringify(n[0].slice(0,80))}`);let i=Number(r[1]),a=[];for(let e of n.slice(1)){if(e===``)continue;let t=e.indexOf(`:`);if(t<=0)throw Error(`malformed header line: ${JSON.stringify(e.slice(0,80))}`);let n=e.slice(0,t).trim().toLowerCase(),r=e.slice(t+1).trim();if(n===`transfer-encoding`)throw Error(`forbidden Transfer-Encoding in response`);a.push([n,r])}return{status:i,headers:a,body:e.subarray(t+4)}}function tt(e){for(let t=0;t+3<e.length;t++)if(e[t]===13&&e[t+1]===10&&e[t+2]===13&&e[t+3]===10)return t;return-1}async function nt(e,t,r){let{openStream:i}=await n(async()=>{let{openStream:e}=await Promise.resolve().then(()=>Ve);return{openStream:e}},void 0),a=await i(e);try{let n=e.slice(e.lastIndexOf(`:`)+1),i=Qe(),o=a.writable.getWriter();await o.write(X(t,n,i)),await o.close();let s=a.readable.getReader(),c=[],l=0;for(;;){let{value:e,done:t}=await s.read();if(t)break;if(l+=e.byteLength,l>r+65536)throw await s.cancel().catch(()=>{}),Error(`response exceeds the ${r}-byte bundle cap`);c.push(e)}let u=new Uint8Array(l),d=0;for(let e of c)u.set(e,d),d+=e.byteLength;let f=et(u);if(f.status!==200)throw Error(`HTTP ${f.status}`);let p=f.headers.find(([e])=>e===`content-encoding`)?.[1].toLowerCase();if(p&&p!==`identity`){if(!i.includes(p))throw Error(`unadvertised Content-Encoding: ${p}`);return $e(p,f.body,r)}if(f.body.byteLength>r)throw Error(`body exceeds the ${r}-byte bundle cap`);return f.body}finally{await a.close().catch(()=>{})}}var rt={matches:e=>e.startsWith(`kps:`),fetch:(e,t)=>{let{addr:n,path:r}=Ze(e);return nt(n,r,t)}},it=1e3,at=class{ready;fetch;#e;#t;#n;#r;#i;#a;#o=new r;#s=new i(it);#c=!1;#l=new Map;#u=1;#d;#f;#p;#m;constructor(e){this.#e=e,this.#t=h(e.config,`config`),this.ready=new Promise((e,t)=>{this.#d=e,this.#f=t}),this.ready.catch(()=>{}),this.fetch=this.#v.bind(this),this.#g().catch(e=>this.#h(e))}#h(e){if(this.#p===void 0){this.#p=e,this.#f(e);for(let t of this.#l.values())t.cleanup?.(),t.reject(e);this.#l.clear(),this.#o.rejectAll(e),this.#s.close(e)}}async#g(){let e=this.#e.preExisting?.rpcProvider;if(!e)throw Error(`preExisting.rpcProvider is required to read the specifier`);let t=await ee(await u(e,this.#e.address),f,[rt]),n=new MessageChannel,r=new He(n.port1);this.#n=r,this.#_(r);let i=document.createElement(`iframe`);i.setAttribute(`sandbox`,`allow-scripts`),i.style.display=`none`,this.#e.iframeUrl?i.src=ot(this.#e.iframeUrl):i.srcdoc=`<!doctype html><meta charset="utf-8"><script>"use strict";
(() => {
  // src/iframe/iframe-boot.ts
  (() => {
    parent.postMessage({ kind: "iframe-ready" }, "*");
    const onInit = (ev) => {
      if (ev.source !== parent || ev.data?.kind !== "init") return;
      removeEventListener("message", onInit);
      const port = ev.ports[0];
      const runtimeSource = ev.data.runtimeSource;
      const bundleBytes = ev.data.bundleBytes;
      const blob = new Blob([runtimeSource], { type: "text/javascript" });
      const worker = new Worker(URL.createObjectURL(blob));
      worker.postMessage({ kind: "init", port, bundleBytes, config: ev.data.config }, [port]);
      worker.addEventListener("error", (e) => {
        parent.postMessage({ kind: "worker-error", message: e.message }, "*");
      });
    };
    addEventListener("message", onInit);
  })();
})();
<\/script>`,this.#r=i;let a=new Promise(e=>{let t=t=>{t.source===i.contentWindow&&(t.data?.kind===`iframe-ready`&&e(),t.data?.kind===`worker-error`&&this.#h(Error(`worker error: ${t.data.message}`)))};this.#a=t,window.addEventListener(`message`,t)});document.body.appendChild(i),await a,i.contentWindow.postMessage({kind:`init`,runtimeSource:`"use strict";
(() => {
  // ../harness-core/dist/errors.js
  var RpcError = class extends Error {
    code;
    constructor(e) {
      super(e.message);
      this.name = e.name;
      this.code = e.code;
    }
  };
  function serializeError(err) {
    if (err instanceof Error) {
      const code = err.code;
      return {
        name: err.name,
        message: err.message,
        ...typeof code === "string" ? { code } : {}
      };
    }
    return { name: "Error", message: String(err) };
  }

  // src/protocol.ts
  var PortRpc = class {
    #port;
    #nextId = 1;
    #pending = /* @__PURE__ */ new Map();
    #handlers = /* @__PURE__ */ new Map();
    #events = /* @__PURE__ */ new Map();
    // AbortControllers for in-flight inbound requests, keyed by caller-side id.
    #inbound = /* @__PURE__ */ new Map();
    constructor(port) {
      this.#port = port;
      port.onmessage = (ev) => this.#onMessage(ev.data);
      port.start?.();
    }
    /** Register a handler for an inbound method. */
    on(method, handler) {
      this.#handlers.set(method, handler);
    }
    /** Register a handler for an inbound fire-and-forget event. */
    onEvent(topic, handler) {
      this.#events.set(topic, handler);
    }
    /** Fire-and-forget event to the peer. */
    emit(topic, data, transfer) {
      this.#post({ t: "evt", topic, data }, transfer);
    }
    /** Call a remote method and await its result. */
    call(method, args, opts) {
      const id = this.#nextId++;
      return new Promise((resolve, reject) => {
        let cleanup;
        if (opts?.signal) {
          const signal = opts.signal;
          if (signal.aborted) {
            reject(abortError());
            return;
          }
          const onAbort = () => {
            if (!this.#pending.delete(id)) return;
            this.#post({ t: "abort", id });
            reject(abortError());
          };
          signal.addEventListener("abort", onAbort);
          cleanup = () => signal.removeEventListener("abort", onAbort);
        }
        this.#pending.set(id, {
          resolve,
          reject,
          cleanup
        });
        this.#post({ t: "req", id, method, args }, opts?.transfer);
      });
    }
    #post(msg, transfer) {
      this.#port.postMessage(msg, transfer ?? []);
    }
    async #onMessage(msg) {
      switch (msg.t) {
        case "evt": {
          this.#events.get(msg.topic)?.(msg.data);
          return;
        }
        case "abort": {
          this.#inbound.get(msg.id)?.abort(abortError());
          return;
        }
        case "res": {
          const p = this.#pending.get(msg.id);
          if (!p) return;
          this.#pending.delete(msg.id);
          p.cleanup?.();
          if (msg.ok) p.resolve(msg.value);
          else p.reject(new RpcError(msg.error));
          return;
        }
        case "req": {
          const handler = this.#handlers.get(msg.method);
          if (!handler) {
            this.#post({
              t: "res",
              id: msg.id,
              ok: false,
              error: { name: "Error", message: \`no handler: \${msg.method}\` }
            });
            return;
          }
          const ac = new AbortController();
          this.#inbound.set(msg.id, ac);
          try {
            const result = await handler(msg.args, { signal: ac.signal });
            this.#post(
              { t: "res", id: msg.id, ok: true, value: result.value },
              result.transfer
            );
          } catch (err) {
            this.#post({
              t: "res",
              id: msg.id,
              ok: false,
              error: serializeError(err)
            });
          } finally {
            this.#inbound.delete(msg.id);
          }
          return;
        }
      }
    }
  };
  function abortError() {
    return new DOMException("The operation was aborted.", "AbortError");
  }

  // src/worker/anon-rpc-worker-api.ts
  function makeWorkerApi(rpc, config) {
    const callAborts = /* @__PURE__ */ new Map();
    const preAborted = /* @__PURE__ */ new Set();
    rpc.onEvent("call-abort", ({ callId }) => {
      const ac = callAborts.get(callId);
      if (ac) ac.abort(new DOMException("aborted", "AbortError"));
      else preAborted.add(callId);
    });
    const streamClosed = /* @__PURE__ */ new Map();
    const connClosed = /* @__PURE__ */ new Map();
    rpc.onEvent("stream.closed", ({ streamId, info }) => {
      streamClosed.get(streamId)?.(info);
      streamClosed.delete(streamId);
    });
    rpc.onEvent("conn.closed", ({ connId, info }) => {
      connClosed.get(connId)?.(info);
      connClosed.delete(connId);
    });
    function makeStream(p) {
      const closed = new Promise((resolve) => streamClosed.set(p.streamId, resolve));
      return {
        readable: p.readable,
        writable: p.writable,
        closeWrite: () => rpc.call("stream.closeWrite", { streamId: p.streamId }),
        cancelRead: (reason) => rpc.call("stream.cancelRead", { streamId: p.streamId, reason }),
        resetWrite: (reason) => rpc.call("stream.resetWrite", { streamId: p.streamId, reason }),
        close: (reason) => rpc.call("stream.close", { streamId: p.streamId, reason }),
        closed
      };
    }
    function makeConn(connId, remoteAddress) {
      const closed = new Promise((resolve) => connClosed.set(connId, resolve));
      return {
        remoteAddress,
        openStream: async (opts) => makeStream(await rpc.call("conn.openStream", { connId }, sigOpt(opts))),
        acceptStream: async (opts) => makeStream(await rpc.call("conn.acceptStream", { connId }, sigOpt(opts))),
        close: (reason) => rpc.call("conn.close", { connId, reason }),
        sendDatagram: (data, opts) => rpc.call("conn.sendDatagram", { connId, data }, sigOpt(opts)),
        receiveDatagram: (opts) => rpc.call("conn.receiveDatagram", { connId }, sigOpt(opts)),
        closed
      };
    }
    const kps = {
      dial: async (addr, opts) => {
        const { connId, remoteAddress } = await rpc.call("kps.dial", { addr }, sigOpt(opts));
        return makeConn(connId, remoteAddress);
      },
      openStream: async (addr, opts) => makeStream(await rpc.call("kps.openStream", { addr }, sigOpt(opts)))
    };
    const storage = {
      get: (key, opts) => rpc.call("storage.get", { key }, sigOpt(opts)),
      set: (key, value, opts) => rpc.call("storage.set", { key, value }, sigOpt(opts)),
      delete: (key, opts) => rpc.call("storage.delete", { key }, sigOpt(opts)),
      has: (key, opts) => rpc.call("storage.has", { key }, sigOpt(opts)),
      clear: (opts) => rpc.call("storage.clear", { prefix: opts?.prefix }, sigOpt(opts)),
      list: (opts) => listKeys(rpc, opts?.prefix, opts?.signal)
    };
    const log = {
      debug: (...args) => rpc.emit("log", { level: "debug", args }),
      info: (...args) => rpc.emit("log", { level: "info", args }),
      warn: (...args) => rpc.emit("log", { level: "warn", args }),
      error: (...args) => rpc.emit("log", { level: "error", args })
    };
    function acceptCall(opts) {
      const abortErr = () => new DOMException("aborted", "AbortError");
      const signal = opts?.signal;
      const toCall = (r) => makeFetchCall(rpc, callAborts, preAborted, r.callId, r.url, r.requestInit);
      if (signal?.aborted) return Promise.reject(signal.reason ?? abortErr());
      const pending = rpc.call("acceptCall", {});
      if (!signal) return pending.then(toCall);
      return new Promise((resolve, reject) => {
        let settled = false;
        const onAbort = () => {
          if (settled) return;
          settled = true;
          pending.then((r) => rpc.emit("requeue-call", { callId: r.callId }), () => {
          });
          reject(signal.reason ?? abortErr());
        };
        signal.addEventListener("abort", onAbort, { once: true });
        pending.then(
          (r) => {
            if (settled) return;
            settled = true;
            signal.removeEventListener("abort", onAbort);
            resolve(toCall(r));
          },
          (e) => {
            if (settled) return;
            settled = true;
            signal.removeEventListener("abort", onAbort);
            reject(e);
          }
        );
      });
    }
    return {
      signalReady: () => rpc.emit("ready", {}),
      // Failure finality (§7: later signals ignored) is enforced host-side —
      // #fail is one-shot and resolving an already-rejected ready is a no-op.
      signalFailed: (reason) => rpc.emit("failed", { reason }),
      acceptCall,
      config,
      kps,
      storage,
      log
    };
  }
  function makeFetchCall(rpc, callAborts, preAborted, callId, url, wireInit) {
    let requestInit;
    if (wireInit) {
      const { hasSignal, forwarded, ...rest } = wireInit;
      requestInit = { ...forwarded, ...rest };
      if (hasSignal) {
        const ac = new AbortController();
        callAborts.set(callId, ac);
        requestInit = { ...requestInit, signal: ac.signal };
        if (preAborted.delete(callId)) ac.abort(new DOMException("aborted", "AbortError"));
      }
    }
    let responded = false;
    return {
      kind: "fetch",
      url,
      ...requestInit ? { requestInit } : {},
      respond(response) {
        if (responded) throw new Error("respond() called more than once");
        responded = true;
        Promise.resolve(response).then((r) => {
          const transfer = r.body instanceof ReadableStream ? [r.body] : r.body instanceof Uint8Array ? [r.body.buffer] : [];
          return rpc.call("respond", { callId, ok: true, response: r }, { transfer });
        }).catch(
          (e) => (
            // Carry name/code across the boundary (§12): host logic may branch
            // on code, never on message text.
            rpc.call("respond", { callId, ok: false, error: serializeError(e) })
          )
        ).catch(() => {
        }).finally(() => callAborts.delete(callId));
      }
    };
  }
  async function* listKeys(rpc, prefix, signal) {
    const keys = await rpc.call("storage.list", { prefix }, signal ? { signal } : void 0);
    for (const k of keys) yield k;
  }
  function sigOpt(opts) {
    return opts?.signal ? { signal: opts.signal } : void 0;
  }

  // src/worker/worker-runtime.ts
  var importScripts = (url) => (
    // eslint-disable-next-line no-restricted-globals
    self.importScripts(url)
  );
  function bundleScriptUrl(bundle) {
    const probeUrl = URL.createObjectURL(new Blob([";"], { type: "text/javascript" }));
    try {
      importScripts(probeUrl);
      return URL.createObjectURL(bundle);
    } catch {
      return new FileReaderSync().readAsDataURL(bundle);
    } finally {
      URL.revokeObjectURL(probeUrl);
    }
  }
  addEventListener("message", function onInit(ev) {
    if (ev.data?.kind !== "init") return;
    removeEventListener("message", onInit);
    const port = ev.data.port;
    const bundleBytes = ev.data.bundleBytes;
    const config = ev.data.config;
    const rpc = new PortRpc(port);
    const api = makeWorkerApi(rpc, config);
    globalThis.anonRpcWorker = api;
    try {
      const blob = new Blob([bundleBytes], { type: "text/javascript" });
      importScripts(bundleScriptUrl(blob));
    } catch (err) {
      const message = err?.message ?? String(err);
      api.log.error("worker bundle failed to load:", message);
      rpc.emit("boot-error", { message });
    }
  });
})();
`,bundleBytes:t,config:this.#t},`*`,[n.port2])}#_(e){this.#i=Ue(e),e.onEvent(`ready`,()=>this.#d()),e.onEvent(`boot-error`,({message:e})=>{this.#h(Error(`worker bundle failed to load: ${e}`))}),e.onEvent(`failed`,({reason:e})=>{this.#h(new C({name:`WorkerFailedError`,message:e?.message??`worker signalled failure`,code:e?.code}))}),e.onEvent(`requeue-call`,({callId:e})=>{let t=this.#l.get(e);t&&this.#o.pushFront(t)}),e.onEvent(`log`,({level:e,args:t})=>{this.#s.push({level:e,args:t}),this.#c||(console[e]??console.log).call(console,`[worker]`,...t.map(st))}),e.on(`acceptCall`,async(e,{signal:t})=>{let n=await this.#o.take(t);return{value:{callId:n.callId,url:n.url,requestInit:n.requestInit},transfer:n.bodyTransfer??[]}}),e.on(`respond`,async e=>{let t=this.#l.get(e.callId);if(!t)return{value:void 0};if(this.#l.delete(e.callId),t.cleanup?.(),e.ok&&e.response)try{t.resolve(ct(e.response))}catch(e){t.reject(e)}else t.reject(new C(e.error??{name:`Error`,message:`worker failed the call`}));return{value:void 0}});let t=this.#e.address.toLowerCase(),n=()=>this.#m??=qe();e.on(`storage.get`,async({key:e})=>({value:await(await n()).get(t,e)})),e.on(`storage.set`,async({key:e,value:r})=>(await(await n()).set(t,e,r),{value:void 0})),e.on(`storage.delete`,async({key:e})=>(await(await n()).delete(t,e),{value:void 0})),e.on(`storage.has`,async({key:e})=>({value:await(await n()).has(t,e)})),e.on(`storage.list`,async({prefix:e})=>({value:await(await n()).listKeys(t,e)})),e.on(`storage.clear`,async({prefix:e})=>(await(await n()).clear(t,e),{value:void 0}))}async#v(e,t){if(this.#p!==void 0)throw this.#p;let{url:n,requestInit:r,transfer:i,signal:a}=await We(e,t),o=this.#u++;return new Promise((e,t)=>{let s={callId:o,url:n,requestInit:r,bodyTransfer:i,resolve:e,reject:t};if(this.#l.set(o,s),a){let e=()=>{this.#o.remove(s)||this.#n?.emit(`call-abort`,{callId:o}),this.#l.delete(o)&&t(a.reason??new DOMException(`aborted`,`AbortError`))};if(a.aborted){this.#l.delete(o),t(a.reason??new DOMException(`aborted`,`AbortError`));return}a.addEventListener(`abort`,e,{once:!0}),s.cleanup=()=>a.removeEventListener(`abort`,e)}this.#o.push(s)})}acceptLog(e){return this.#c=!0,this.#s.take(e?.signal)}close(){this.#i?.(),this.#a&&window.removeEventListener(`message`,this.#a),this.#r?.remove(),this.#h(Error(`worker closed`))}};function ot(e){let t;try{t=new URL(e,location.href)}catch{throw Error(`iframeUrl is not a valid URL: ${e}`)}if(t.origin!==location.origin)throw Error(`iframeUrl must be same-origin with the host (${location.origin}), got ${t.origin} \u2014 a cross-origin bootstrap would control the isolation boundary (\xA76)`);return t.href}function st(e){return e instanceof Uint8Array?`<${e.byteLength} bytes>`:e}function ct(e){let t=new Headers;for(let[n,r]of e.headers)t.append(n,r);let n=e.status,r=n===204||n===205||n===304?null:e.body,i=new Response(r,{status:n,headers:t});return e.url&&Object.defineProperty(i,"url",{value:e.url}),i}export{h as a,i as c,S as i,C as n,b as o,w as r,ie as s,at as t};